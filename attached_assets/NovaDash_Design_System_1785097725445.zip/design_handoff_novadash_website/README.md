# Handoff: NovaDash Website (Brand + Design System)

## Overview
Komplettes Markenpaket für die NovaDash-Website: neues Logo (Barcode-Wortmarke), Favicons, Design-Tokens, Komponenten-Referenzen und die Marketing-Site als Design-Vorlage. NovaDash ist ein SaaS für kleine und mittlere Online-Seller auf eBay & Amazon (DACH).

## About the Design Files
Die Dateien in diesem Paket sind **Design-Referenzen in HTML/JSX** — Prototypen, die Aussehen und Verhalten zeigen, kein Produktionscode zum direkten Kopieren. Aufgabe: diese Designs in der Zielumgebung (z.B. React/Next.js auf Replit) mit deren etablierten Patterns nachbauen. Existiert noch kein Setup, wähle ein passendes Framework (Empfehlung: React oder Next.js) und implementiere die Designs dort. Die SVG/PNG-Assets in `assets/` sind dagegen **produktionsfertig** und können direkt verwendet werden.

## Fidelity
**High-fidelity.** Farben, Typografie, Abstände und Komponenten sind final — pixelgenau umsetzen, exakte Werte stehen in `tokens/*.css`.

## Logo
"Nova [Barcode] Dash" — Space Grotesk Medium (500), der Barcode ersetzt den Bindestrich.
- Lockup: `assets/logo.svg` · App-Icon: `assets/logo-icon.svg`
- Hell: Text `#1A2E23`, Barcode `#0F766E` · Dunkel: Text `#fff`, Barcode `#7BC5A8`
- Größen: Header 24px Wortgröße, Footer 20px; Barcode-Höhe = 0,64 × Wortgröße, baseline-aligned, Gap = 0,28 × Wortgröße
- Referenz-Implementierung (React): `components/brand/Logo.jsx` (Logo, LogoIcon, Barcode)
- Regeln: nie das alte Serifen-N-Quadrat verwenden; Wortmarke nie sperren (kein letter-spacing)

## Favicons (produktionsfertig, direkt einbinden)
```html
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon-32.png" sizes="32x32">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
```
Dateien: favicon.svg, favicon-16/32/48.png (Tab), favicon-192/512.png (PWA/Android-Manifest), apple-touch-icon.png (180px, eckig — iOS rundet selbst). Kleine Größen nutzen bewusst eine vereinfachte 5-Balken-Version.

## Design Tokens
Alle Werte in `tokens/` (CSS Custom Properties), eingebunden über `styles.css`:
- `colors.css` — Emerald-Palette (Primary `#0F766E` = --nd-emerald-700), Forest-Dunkeltöne, Text `#1A2E23`, Mint-Akzent `#7BC5A8`
- `typography.css` — Schriften: **Space Grotesk** (--font-display, Logo), **Cormorant Garamond** (--font-serif, Headlines; kursiv für Akzentwörter), **Nunito** (--font-sans, Fließtext), **JetBrains Mono** (--font-mono, Eyebrows/Nav/Preise); Typo-Skala
- `spacing.css` — Abstands-Skala
- `fonts.css` — Google-Fonts-Import (alle vier Familien)

## Screens / Views
`ui_kits/marketing-site/` enthält die komplette Marketing-Site als React-Referenz:
- `HomePage.jsx` — Hero (Serif-Headline mit kursivem Akzent, Badge, CTA), Partner-Logos als Text, Feature-Sektionen, CTA-Block
- `PricingPage.jsx` — Pricing mit dunklem CTA-Abschnitt
- `index.html` — lauffähige Vorschau der Referenz

## Components
`components/` — React-Referenzimplementierungen mit Props-Doku (`.d.ts`) und Nutzungsregeln (`.prompt.md`): Logo, Badge, Button, Card, ChecklistItem, Divider, Eyebrow, FeatureIcon, Icon.

## Interactions & Behavior
- Links/Buttons: Hover via --color-primary-hover; Buttons mit weichem Emerald-Schatten (`0 10px 15px -3px rgba(4,120,87,0.2)` bei großen CTAs)
- Scroll-Reveal: Klasse `nd-botanical-fade-up` (sanftes Einblenden von unten)
- Keine Icon-Fonts, keine Emojis; nummerierte Listen in Mono "01/02/03"
- Partner (Amazon, eBay, DHL …) als gestylter Text, nicht als Logos

## Assets
`assets/`: logo.svg, logo-icon.svg, alle Favicons, nd-hero-dashboard.png, nd-process-labels.png. Alle selbst erstellt bzw. aus dem NovaDash-Designpaket — frei verwendbar.

## Files
- `design-system-readme.md` — vollständige Design-System-Doku (Regeln, Index)
- `styles.css` + `tokens/` — Design-Tokens
- `components/` — Komponenten-Referenzen (JSX + .d.ts + .prompt.md)
- `ui_kits/marketing-site/` — Marketing-Site-Referenz
