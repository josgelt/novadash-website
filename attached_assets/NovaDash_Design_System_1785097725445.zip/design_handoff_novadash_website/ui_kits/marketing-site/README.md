# NovaDash Marketing Site — UI Kit

Click-through recreation of the NovaDash marketing website (source: `pages/Home.tsx`, `Pricing.tsx`, `Uptime.tsx`, `components/Header.tsx`, `Footer.tsx`).

- `index.html` — interactive shell: nav between Home / Preise / Status, working header scroll-blur, hover states.
- `SiteChrome.jsx` — Header + Footer (composes Logo, Button, Icon).
- `HomePage.jsx`, `PricingPage.jsx`, `UptimePage.jsx` — page recreations.

Notes: German copy (site is DE-first); DE/EN toggle is visual-only since English source copy was not provided. Hero/process imagery cropped from source screenshots (`assets/`). The Uptime page embeds a placeholder panel where the live BetterUptime iframe sits in production.
