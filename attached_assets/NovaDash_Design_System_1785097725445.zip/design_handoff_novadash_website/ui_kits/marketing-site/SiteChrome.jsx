const { Logo, Button, Icon } = window.NovaDashDesignSystem_179bbc;
const mono = { fontFamily: 'var(--font-mono)' };
function Header({ page, onNav, scrolled }) {
  const links = [['home','Home'],['funktionen','Funktionen'],['preise','Preise'],['ueber-uns','Über uns'],['kontakt','Kontakt']];
  return (
    <header style={{position:'sticky',top:0,zIndex:50,transition:'all 0.5s',padding:scrolled?'16px 0':'24px 0',background:scrolled?'rgba(248,250,249,0.9)':'transparent',backdropFilter:scrolled?'blur(12px)':'none',borderBottom:scrolled?'1px solid var(--color-border)':'1px solid transparent'}}>
      <div style={{maxWidth:1280,margin:'0 auto',padding:'0 48px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <Logo href="#" />
        <nav style={{display:'flex',alignItems:'center',gap:40,...mono,fontSize:14,textTransform:'uppercase',letterSpacing:'0.05em'}}>
          {links.map(([id,label]) => (
            <a key={id} href="#" onClick={(e)=>{e.preventDefault();onNav(id);}} style={{textDecoration:'none',color:page===id?'var(--color-primary)':'var(--color-text-muted)',fontWeight:page===id?600:400,borderBottom:page===id?'2px solid var(--color-primary)':'2px solid transparent',paddingBottom:4,transition:'color 0.2s'}}
              onMouseEnter={(e)=>{if(page!==id)e.currentTarget.style.color='var(--color-primary)';}} onMouseLeave={(e)=>{if(page!==id)e.currentTarget.style.color='var(--color-text-muted)';}}>{label}</a>
          ))}
        </nav>
        <div style={{display:'flex',alignItems:'center',gap:24}}>
          <div style={{display:'flex',alignItems:'center',gap:12,...mono,fontSize:12,textTransform:'uppercase',letterSpacing:'0.15em',color:'var(--color-text-muted)'}}>
            <span style={{color:'var(--color-text)',fontWeight:600}}>DE</span><span style={{color:'var(--color-border)'}}>|</span><span>EN</span>
          </div>
          <Button size="md">Early Access</Button>
        </div>
      </div>
    </header>
  );
}
function Footer({ onNav }) {
  const col = (title, items) => (
    <div>
      <h5 style={{...mono,fontSize:12,fontWeight:600,letterSpacing:'0.15em',textTransform:'uppercase',color:'var(--color-text)',margin:'0 0 24px'}}>{title}</h5>
      <ul style={{listStyle:'none',margin:0,padding:0,display:'flex',flexDirection:'column',gap:16,fontSize:14,color:'var(--color-text-muted)'}}>
        {items.map(([id,label,bold]) => <li key={label}><a href="#" onClick={(e)=>{e.preventDefault();if(id)onNav(id);}} style={{color:'inherit',textDecoration:'none',fontWeight:bold?600:400}}
          onMouseEnter={(e)=>e.currentTarget.style.color='var(--color-primary)'} onMouseLeave={(e)=>e.currentTarget.style.color='inherit'}>{label}</a></li>)}
      </ul>
    </div>
  );
  return (
    <footer style={{background:'var(--color-bg)',borderTop:'1px solid var(--color-border)',padding:'80px 48px 40px'}}>
      <div style={{maxWidth:1280,margin:'0 auto'}}>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:48,marginBottom:64}}>
          <div>
            <div style={{marginBottom:24}}><Logo size="sm" href="#" /></div>
            <p style={{...mono,fontSize:14,color:'var(--color-text-muted)',lineHeight:1.6,margin:'0 0 24px'}}>Cloud Order-Management für den DACH-Raum.</p>
            <div style={{display:'flex',alignItems:'center',gap:12,...mono,fontSize:12,textTransform:'uppercase',letterSpacing:'0.15em',color:'var(--color-text-muted)'}}>
              <span style={{color:'var(--color-text)',fontWeight:600,borderBottom:'1px solid var(--color-text)',paddingBottom:2}}>DE</span><span style={{color:'var(--color-border)'}}>|</span><span>EN</span>
            </div>
          </div>
          {col('Produkt',[['funktionen','Funktionen'],['preise','Preise'],['funktionen','Integrationen'],[null,'Early Access',true]])}
          {col('Unternehmen',[['ueber-uns','Über uns'],['kontakt','Kontakt'],['status','Status']])}
          {col('Rechtliches',[[null,'Impressum'],[null,'Datenschutz'],[null,'AGB'],[null,'Sub-Processor-Liste']])}
        </div>
        <div style={{paddingTop:32,borderTop:'1px solid var(--color-border)',textAlign:'center',...mono,fontSize:12,color:'var(--color-text-muted)'}}>© 2026 NovaDash GmbH. Alle Rechte vorbehalten.</div>
      </div>
    </footer>
  );
}
Object.assign(window, { Header, Footer });
