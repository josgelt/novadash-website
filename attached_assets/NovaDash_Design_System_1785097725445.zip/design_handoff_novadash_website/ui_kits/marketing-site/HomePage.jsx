const { Button, Badge, Eyebrow, Divider, Card, ChecklistItem, FeatureIcon, Icon } = window.NovaDashDesignSystem_179bbc;
const serif = { fontFamily: 'var(--font-serif)' };
const monoS = { fontFamily: 'var(--font-mono)' };
function SectionHead({ eyebrow, color, title, accent2, sub, center }) {
  return (
    <div style={{maxWidth:672,margin:center?'0 auto 80px':'0',textAlign:center?'center':'left'}}>
      <Eyebrow color={color} style={{marginBottom:16}}>{eyebrow}</Eyebrow>
      <h2 style={{...serif,fontWeight:600,fontSize:44,lineHeight:1.15,color:'var(--color-text)',margin:'0 0 24px'}}>{title}{accent2 && <><br/><span style={{fontStyle:'italic',color:'var(--color-primary)'}}>{accent2}</span></>}</h2>
      {sub && <p style={{fontSize:18,lineHeight:1.625,color:'var(--color-text-muted)',margin:0}}>{sub}</p>}
    </div>
  );
}
function HomePage({ onNav }) {
  const glow = (pos, color, op) => <div style={{position:'absolute',...pos,width:600,height:600,background:color,opacity:op,filter:'blur(100px)',borderRadius:'50%',pointerEvents:'none'}}></div>;
  return (
    <div>
      <section style={{padding:'80px 48px 112px',position:'relative',overflow:'hidden'}}>
        <div className="nd-botanical-dots" style={{position:'absolute',inset:0,opacity:0.5,pointerEvents:'none'}}></div>
        {glow({top:'-10%',right:'-5%'},'var(--color-primary)',0.07)}
        {glow({bottom:0,left:'-10%'},'var(--color-accent)',0.05)}
        <div style={{maxWidth:1280,margin:'0 auto',position:'relative',display:'grid',gridTemplateColumns:'1fr 1fr',gap:64,alignItems:'center'}}>
          <div className="nd-botanical-fade-up">
            <Badge icon={<Icon name="terminal" size={14} style={{color:'var(--color-accent)'}}/>} style={{marginBottom:32}}>V2.0 Beta live</Badge>
            <h1 style={{...serif,fontWeight:600,fontSize:64,lineHeight:1.1,letterSpacing:'-0.01em',color:'var(--color-text)',margin:'0 0 32px'}}>Alle Marktplätze.<br/><span style={{fontStyle:'italic',fontWeight:500,color:'var(--color-primary)'}}>Eine</span> Oberfläche.</h1>
            <p style={{fontSize:18,lineHeight:1.625,color:'var(--color-text-muted)',maxWidth:512,margin:'0 0 40px'}}>Die cloudbasierte Order-Management-Plattform für E-Commerce im DACH-Raum. Verwalten Sie Bestellungen, Versand und Tracking automatisiert an einer zentralen Stelle.</p>
            <div style={{display:'flex',gap:16}}>
              <Button size="lg">Early Access anfragen <Icon name="arrow-right" size={16}/></Button>
              <Button variant="secondary" size="lg">Funktionen ansehen</Button>
            </div>
          </div>
          <div className="nd-botanical-fade-up nd-delay-200" style={{position:'relative'}}>
            <div style={{borderRadius:12,overflow:'hidden',border:'1px solid var(--color-border)',background:'#fff',boxShadow:'0 25px 50px -12px rgba(4,120,87,0.1)'}}>
              <div style={{height:32,background:'#F9FAFB',borderBottom:'1px solid var(--color-border)',display:'flex',alignItems:'center',padding:'0 16px',gap:8}}>
                <span style={{width:10,height:10,borderRadius:'50%',background:'#F87171'}}></span><span style={{width:10,height:10,borderRadius:'50%',background:'#FBBF24'}}></span><span style={{width:10,height:10,borderRadius:'50%',background:'#4ADE80'}}></span>
              </div>
              <img src="../../assets/nd-hero-dashboard.png" alt="NovaDash Dashboard" style={{display:'block',width:'100%'}}/>
            </div>
            <div style={{position:'absolute',bottom:-24,left:-32,background:'#fff',padding:16,border:'1px solid var(--color-border)',borderRadius:8,boxShadow:'0 20px 25px -5px rgba(0,0,0,0.1)',maxWidth:300,zIndex:20}}>
              <div style={{display:'flex',alignItems:'center',gap:16,marginBottom:12}}>
                <div style={{width:40,height:40,borderRadius:4,background:'var(--color-bg)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--color-primary)'}}><Icon name="package" size={18}/></div>
                <div>
                  <div style={{...monoS,fontSize:11,textTransform:'uppercase',letterSpacing:'0.05em',color:'var(--color-text-muted)',marginBottom:2}}>Order ID</div>
                  <div style={{...monoS,fontSize:14,fontWeight:700,color:'var(--color-text)'}}>#10492-DE</div>
                </div>
              </div>
              <div style={{display:'flex',justifyContent:'space-between',...monoS,fontSize:12,color:'var(--color-text-muted)'}}><span>Status</span><span style={{color:'var(--color-primary)',fontWeight:600}}>SYNCED</span></div>
            </div>
          </div>
        </div>
      </section>
      <section style={{padding:'48px',background:'#fff',borderTop:'1px solid var(--color-border)',borderBottom:'1px solid var(--color-border)'}}>
        <div style={{maxWidth:1280,margin:'0 auto'}}>
          <p style={{textAlign:'center',...monoS,fontSize:12,letterSpacing:'0.2em',color:'var(--color-text-muted)',textTransform:'uppercase',margin:'0 0 32px'}}>Nahtlose API-Integrationen</p>
          <div style={{display:'flex',flexWrap:'wrap',justifyContent:'center',gap:'40px 80px',alignItems:'center',color:'rgba(75,90,82,0.6)'}}>
            <span style={{...serif,fontSize:24}}>Amazon</span>
            <span style={{...serif,fontSize:24,fontStyle:'italic'}}>eBay</span>
            <span style={{fontSize:24,letterSpacing:'-0.02em',fontWeight:600}}>Shopify</span>
            <span style={{...serif,fontSize:24,fontWeight:700,letterSpacing:'0.15em'}}>DHL</span>
            <span style={{fontSize:24,fontWeight:700}}>GLS</span>
            <span style={{...serif,fontSize:24}}>Sendcloud</span>
            <span style={{...monoS,fontSize:24,fontWeight:600,letterSpacing:'0.05em'}}>REST_API</span>
          </div>
        </div>
      </section>
      <section style={{padding:'128px 48px',position:'relative'}}>
        <div className="nd-botanical-grid" style={{position:'absolute',inset:0,opacity:0.3,pointerEvents:'none'}}></div>
        <div style={{maxWidth:1280,margin:'0 auto',position:'relative',display:'grid',gridTemplateColumns:'5fr 7fr',gap:96,alignItems:'center'}}>
          <div style={{borderRadius:12,border:'1px solid var(--color-border)',boxShadow:'0 20px 25px -5px rgba(0,0,0,0.1)',background:'#fff',padding:8}}>
            <div style={{borderRadius:8,overflow:'hidden',border:'1px solid rgba(226,232,228,0.5)'}}>
              <img src="../../assets/nd-process-labels.png" alt="Versandprozess" style={{display:'block',width:'100%'}}/>
            </div>
          </div>
          <div>
            <Eyebrow color="accent" style={{marginBottom:16}}>Skalierbarkeit</Eyebrow>
            <h2 style={{...serif,fontWeight:600,fontSize:44,lineHeight:1.15,color:'var(--color-text)',margin:'0 0 24px'}}>Wachsen Sie nicht aus Ihren Prozessen heraus.</h2>
            <Divider style={{marginBottom:32}}/>
            <p style={{fontSize:18,lineHeight:1.625,color:'var(--color-text-muted)',margin:'0 0 40px'}}>Mit jedem neuen Marktplatz multipliziert sich der Verwaltungsaufwand. Was mit 10 Bestellungen am Tag funktionierte, führt bei 100 zum Systemkollaps. Zeit ist Ihr wertvollstes Gut – verschwenden Sie sie nicht mit Copy &amp; Paste.</p>
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <ChecklistItem boxed>Kein Einloggen in 5 verschiedene Portale mehr</ChecklistItem>
              <ChecklistItem boxed>Reduzierung manueller Übertragungsfehler auf 0</ChecklistItem>
              <ChecklistItem boxed>Skalierbare Prozesse für das Weihnachtsgeschäft</ChecklistItem>
            </div>
          </div>
        </div>
      </section>
      <section style={{padding:'128px 48px',background:'#fff',borderTop:'1px solid var(--color-border)'}}>
        <div style={{maxWidth:1280,margin:'0 auto'}}>
          <SectionHead center eyebrow="Core Features" title="Alles an einem Ort." accent2="Vollautomatisiert." sub="NovaDash ist nicht einfach ein weiteres Tool, sondern das Betriebssystem für Ihren E-Commerce-Erfolg."/>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:32}}>
            {[['globe',false,'Zentrales Order-Management','Bestellungen von Amazon, eBay, Ihrem Onlineshop und mehr laufen in Echtzeit in einer sauberen Liste zusammen.'],
              ['truck',true,'Automatisierte Labels','Regelbasierter Versand. Mit einem Klick das günstigste Label erstellen – egal ob DHL, GLS oder DPD.'],
              ['activity',false,'Echtzeit-Sendungsverfolgung','Automatischer Rückfluss der Tracking-IDs an die Marktplätze. Ihre Kunden sind immer informiert.']].map(([icon,accent,title,desc]) => (
              <Card key={title}>
                <FeatureIcon name={icon} accent={accent} style={{marginBottom:32}}/>
                <h3 style={{...serif,fontWeight:600,fontSize:20,color:'var(--color-text)',margin:'0 0 12px'}}>{title}</h3>
                <p style={{fontSize:14,lineHeight:1.625,color:'var(--color-text-muted)',margin:0}}>{desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
      <section style={{padding:'112px 48px',background:'var(--color-bg-alt)',borderTop:'1px solid var(--color-border)',borderBottom:'1px solid var(--color-border)',textAlign:'center',position:'relative',overflow:'hidden'}}>
        <div className="nd-botanical-dots" style={{position:'absolute',inset:0,opacity:0.4,pointerEvents:'none'}}></div>
        <div style={{maxWidth:768,margin:'0 auto',position:'relative'}}>
          <h2 style={{...serif,fontWeight:600,fontSize:36,color:'var(--color-text)',margin:'0 0 16px'}}>Transparente Preise.</h2>
          <p style={{fontSize:18,color:'var(--color-text-muted)',margin:'0 0 40px'}}>Skalierbare Pläne für jedes Volumen.</p>
          <a href="#" onClick={(e)=>{e.preventDefault();onNav('preise');}} style={{display:'inline-block',padding:40,background:'#fff',border:'1px solid var(--color-border)',borderRadius:16,boxShadow:'0 20px 25px -5px rgba(4,120,87,0.05)',textDecoration:'none',transition:'border-color 0.3s'}}
            onMouseEnter={(e)=>e.currentTarget.style.borderColor='rgba(4,120,87,0.5)'} onMouseLeave={(e)=>e.currentTarget.style.borderColor='var(--color-border)'}>
            <Badge variant="tint" style={{marginBottom:24}}>Early Access</Badge>
            <div style={{...monoS,fontSize:56,fontWeight:600,letterSpacing:'-0.04em',color:'var(--color-text)',marginBottom:12}}>€ 49 <span style={{fontSize:18,color:'var(--color-text-muted)',fontFamily:'var(--font-sans)',fontWeight:400,letterSpacing:'normal'}}>/ Monat</span></div>
            <div style={{...monoS,fontSize:14,color:'var(--color-primary)',textTransform:'uppercase',letterSpacing:'0.05em',marginTop:24}}>Alle Pläne ansehen</div>
          </a>
        </div>
      </section>
      <section style={{padding:'112px 48px',background:'var(--color-secondary)',color:'#fff',position:'relative'}}>
        <div className="nd-botanical-grid" style={{position:'absolute',inset:0,opacity:0.1,pointerEvents:'none'}}></div>
        <div style={{maxWidth:1280,margin:'0 auto',position:'relative',display:'grid',gridTemplateColumns:'5fr 1fr 6fr',gap:0}}>
          <div>
            <Eyebrow style={{marginBottom:24}}>Vertrauen &amp; Sicherheit</Eyebrow>
            <h2 style={{...serif,fontWeight:600,fontSize:40,lineHeight:1.2,color:'#fff',margin:'0 0 32px'}}>Ihre Daten. Deutsche Server. Volle Kontrolle.</h2>
            <Divider onDark style={{marginBottom:32}}/>
            <p style={{color:'rgba(255,255,255,0.8)',fontSize:18,lineHeight:1.625,margin:'0 0 40px'}}>Sicherheit ist keine Funktion, sondern das Fundament. NovaDash wird in Deutschland entwickelt und betrieben.</p>
            <Badge variant="dark" icon={<Icon name="shield-check" size={16} style={{color:'var(--color-primary)'}}/>}>DSGVO-konform</Badge>
          </div>
          <div></div>
          <div style={{display:'flex',flexDirection:'column',justifyContent:'center',gap:32}}>
            {[['01','Hosting in Deutschland','Alle Daten liegen ausschließlich in zertifizierten deutschen Rechenzentren.'],
              ['02','DSGVO-konform','Datenschutz nach höchsten europäischen Standards – inklusive AV-Vertrag.'],
              ['03','Verschlüsselte Übertragung','Ende-zu-Ende-Verschlüsselung für alle Bestell- und Kundendaten.']].map(([num,title,desc]) => (
              <Card dark key={num}>
                <h4 style={{...serif,fontSize:24,fontWeight:500,color:'#fff',margin:'0 0 12px',display:'flex',alignItems:'center',gap:16}}><span style={{...monoS,fontSize:14,letterSpacing:'0.1em',textTransform:'uppercase',color:'var(--color-primary)'}}>{num}</span>{title}</h4>
                <p style={{color:'rgba(255,255,255,0.7)',fontSize:14,lineHeight:1.625,margin:0,paddingLeft:40}}>{desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
      <section style={{padding:'128px 48px',background:'#fff',borderTop:'1px solid var(--color-border)',position:'relative',overflow:'hidden'}}>
        <div style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',width:600,height:600,background:'var(--color-primary)',opacity:0.05,borderRadius:'50%',filter:'blur(80px)',pointerEvents:'none'}}></div>
        <div style={{maxWidth:896,margin:'0 auto',textAlign:'center',position:'relative'}}>
          <h2 style={{...serif,fontWeight:600,fontSize:44,lineHeight:1.2,color:'var(--color-text)',margin:'0 0 24px'}}>Bereit für effizientes<br/><span style={{fontStyle:'italic',color:'var(--color-primary)'}}>Order-Management?</span></h2>
          <p style={{fontSize:18,color:'var(--color-text-muted)',maxWidth:672,margin:'0 auto 40px'}}>Wir vergeben aktuell exklusive Plätze für unsere Early Access Phase. Sichern Sie sich Ihren Zugang und gestalten Sie die Zukunft des E-Commerce mit.</p>
          <Button size="lg" style={{boxShadow:'0 10px 15px -3px rgba(4,120,87,0.2)'}}>Jetzt für den Early Access vormerken <Icon name="arrow-right" size={16}/></Button>
        </div>
      </section>
    </div>
  );
}
Object.assign(window, { HomePage, SectionHead });
