const { Button, Badge, Eyebrow, Divider, Card, ChecklistItem, Icon } = window.NovaDashDesignSystem_179bbc;
const serifP = { fontFamily: 'var(--font-serif)' };
const monoP = { fontFamily: 'var(--font-mono)' };
function PricingPage() {
  const tiers = [
    { name: 'Starter', price: '€ 49 / Monat [Platzhalter]', features: ['Bis zu 500 Bestellungen/Monat','2 Marktplätze','Standard-Support'] },
    { name: 'Professional', price: '€ 149 / Monat [Platzhalter]', features: ['Bis zu 2.000 Bestellungen/Monat','Unlimitierte Marktplätze','Prioritäts-Support','Automatisierungsregeln'], popular: true },
    { name: 'Business', price: '€ 399 / Monat [Platzhalter]', features: ['Unlimitierte Bestellungen','Dedizierter Account Manager','Custom Onboarding','API-Zugang'] },
  ];
  return (
    <div>
      <section style={{padding:'80px 48px 96px',position:'relative',overflow:'hidden'}}>
        <div className="nd-botanical-dots" style={{position:'absolute',inset:0,opacity:0.5,pointerEvents:'none'}}></div>
        <div style={{position:'absolute',top:'-10%',right:'-5%',width:600,height:600,background:'var(--color-primary)',opacity:0.06,filter:'blur(100px)',borderRadius:'50%',pointerEvents:'none'}}></div>
        <div style={{maxWidth:896,margin:'0 auto',textAlign:'center',position:'relative'}} className="nd-botanical-fade-up">
          <Eyebrow style={{marginBottom:16}}>Preise</Eyebrow>
          <h1 style={{...serifP,fontWeight:600,fontSize:64,lineHeight:1.1,letterSpacing:'-0.01em',color:'var(--color-text)',margin:'0 0 24px'}}>Preise</h1>
          <p style={{fontSize:20,color:'var(--color-text-muted)',margin:'0 0 32px'}}>Skalierbare Pläne für jedes Volumen</p>
          <Badge>Hinweis: Während der Early-Access-Phase gelten Sonderkonditionen.</Badge>
        </div>
      </section>
      <section style={{padding:'112px 48px',background:'#fff',borderTop:'1px solid var(--color-border)'}}>
        <div style={{maxWidth:1152,margin:'0 auto',display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:32,alignItems:'stretch'}}>
          {tiers.map((tier) => (
            <Card key={tier.name} hoverable={!tier.popular} style={tier.popular?{border:'1px solid var(--color-primary)',boxShadow:'0 20px 25px -5px rgba(4,120,87,0.1),0 0 0 1px var(--color-primary)',marginTop:-16,position:'relative',display:'flex',flexDirection:'column'}:{display:'flex',flexDirection:'column'}}>
              {tier.popular && <div style={{position:'absolute',top:0,left:'50%',transform:'translate(-50%,-50%)'}}><Badge variant="solid">Beliebt</Badge></div>}
              <h3 style={{...serifP,fontWeight:600,fontSize:24,color:'var(--color-text)',margin:'0 0 8px'}}>{tier.name}</h3>
              <div style={{...monoP,fontSize:18,color:'var(--color-text-muted)',marginBottom:24}}>{tier.price}</div>
              <Divider style={{marginBottom:32}}/>
              <div style={{flex:1,display:'flex',flexDirection:'column',gap:16,marginBottom:40}}>
                {tier.features.map((f) => <ChecklistItem key={f}>{f}</ChecklistItem>)}
              </div>
              <Button variant={tier.popular?'primary':'secondary'} style={{width:'100%'}}>Early Access</Button>
            </Card>
          ))}
        </div>
      </section>
      <section style={{padding:'128px 48px',background:'var(--color-secondary)',color:'#fff',position:'relative',overflow:'hidden'}}>
        <div className="nd-botanical-grid" style={{position:'absolute',inset:0,opacity:0.1,pointerEvents:'none'}}></div>
        <div style={{maxWidth:768,margin:'0 auto',textAlign:'center',position:'relative'}}>
          <h2 style={{...serifP,fontWeight:600,fontSize:44,lineHeight:1.2,color:'#fff',margin:'0 0 24px'}}>Bereit für effizientes <span style={{fontStyle:'italic',color:'var(--color-primary)'}}>Order-Management?</span></h2>
          <p style={{fontSize:18,color:'rgba(255,255,255,0.8)',maxWidth:672,margin:'0 auto 40px'}}>Wir vergeben aktuell exklusive Plätze für unsere Early Access Phase. Sichern Sie sich Ihren Zugang und gestalten Sie die Zukunft des E-Commerce mit.</p>
          <Button size="lg">Jetzt für den Early Access vormerken <Icon name="arrow-right" size={16}/></Button>
        </div>
      </section>
    </div>
  );
}
function UptimePage() {
  return (
    <div>
      <section style={{padding:'80px 48px 64px',position:'relative',overflow:'hidden'}}>
        <div className="nd-botanical-dots" style={{position:'absolute',inset:0,opacity:0.5,pointerEvents:'none'}}></div>
        <div style={{position:'absolute',top:'-10%',right:'-5%',width:600,height:600,background:'var(--color-primary)',opacity:0.06,filter:'blur(100px)',borderRadius:'50%',pointerEvents:'none'}}></div>
        <div style={{maxWidth:1024,margin:'0 auto',position:'relative'}} className="nd-botanical-fade-up">
          <Eyebrow style={{marginBottom:16}}>System-Status</Eyebrow>
          <h1 style={{...serifP,fontWeight:600,fontSize:64,lineHeight:1.1,letterSpacing:'-0.01em',color:'var(--color-text)',margin:'0 0 24px'}}>Status</h1>
          <p style={{fontSize:18,lineHeight:1.625,color:'var(--color-text-muted)',maxWidth:672,margin:0}}>Live-Verfügbarkeit aller NovaDash-Systeme, überwacht rund um die Uhr.</p>
        </div>
      </section>
      <section style={{padding:'0 48px 96px',position:'relative'}}>
        <div style={{maxWidth:1024,margin:'0 auto'}}>
          <div style={{height:420,background:'#fff',border:'1px solid var(--color-border)',borderRadius:12,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:12}}>
            <span style={{width:12,height:12,borderRadius:'50%',background:'var(--color-primary)'}}></span>
            <div style={{fontFamily:'var(--font-mono)',fontSize:13,color:'var(--color-text)',fontWeight:600,letterSpacing:'0.1em',textTransform:'uppercase'}}>Alle Systeme betriebsbereit</div>
            <div style={{fontFamily:'var(--font-mono)',fontSize:11,color:'var(--color-text-muted)'}}>[Platzhalter — hier bindet die Produktion novadash.betteruptime.com als iframe ein]</div>
          </div>
          <div style={{marginTop:24,textAlign:'center'}}>
            <a href="#" onClick={(e)=>e.preventDefault()} style={{display:'inline-flex',alignItems:'center',gap:8,fontFamily:'var(--font-mono)',fontSize:14,textTransform:'uppercase',letterSpacing:'0.05em',color:'var(--color-primary)',textDecoration:'none'}}>Statusseite extern öffnen <Icon name="arrow-right" size={14}/></a>
          </div>
        </div>
      </section>
    </div>
  );
}
Object.assign(window, { PricingPage, UptimePage });
