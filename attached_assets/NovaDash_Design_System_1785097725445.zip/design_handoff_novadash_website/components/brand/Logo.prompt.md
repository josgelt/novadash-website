# Logo
"Nova [barcode] Dash" — Space Grotesk Medium (--font-display), the barcode glyph replaces the dash.
- `<Logo size="md|sm" variant="light|dark" href>` — full lockup. dark = white text + mint (#7BC5A8) barcode for dark surfaces.
- `<LogoIcon size={n}/>` — square app-icon mark (white barcode on emerald, rounded).
- `<Barcode height={n} color/>` — the glyph alone.
Assets: assets/logo.svg (lockup), assets/logo-icon.svg (icon).
Favicons in assets/: favicon.svg, favicon-16/32/48/192/512.png, apple-touch-icon.png (180px, square — iOS rounds it). Usage:
\`\`\`html
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
<link rel="icon" href="assets/favicon-32.png" sizes="32x32">
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png">
\`\`\`
Never recreate the old serif-N square; never letter-space the wordmark.
