/** NovaDash logo: "Nova [barcode] Dash" — Space Grotesk Medium wordmark, emerald barcode replacing the dash. */
export interface LogoProps {
  /** 'md' (header, 24px word) | 'sm' (footer, 20px word). Default 'md'. */
  size?: 'sm' | 'md';
  /** 'light' (default, dark text) | 'dark' (white text, mint barcode — for dark surfaces). */
  variant?: 'light' | 'dark';
  href?: string;
  style?: React.CSSProperties;
}
/** Square app-icon mark: white barcode on emerald, rounded. */
export interface LogoIconProps { size?: number; radius?: number; style?: React.CSSProperties; }
/** The barcode glyph alone. */
export interface BarcodeProps { height?: number; color?: string; style?: React.CSSProperties; }
