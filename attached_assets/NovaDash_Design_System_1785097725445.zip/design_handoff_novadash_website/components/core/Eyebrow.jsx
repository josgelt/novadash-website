import React from 'react';
// Mono uppercase section eyebrow (source: "SKALIERBARKEIT", "CORE FEATURES", …)
export function Eyebrow({ color = 'primary', children, style }) {
  const colors = { primary: 'var(--color-primary)', accent: 'var(--color-accent)', muted: 'var(--color-text-muted)', onDark: 'var(--color-primary)' };
  return <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: colors[color], ...style }}>{children}</div>;
}
