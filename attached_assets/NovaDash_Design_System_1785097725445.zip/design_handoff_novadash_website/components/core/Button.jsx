import React from 'react';
// NovaDash button — JetBrains Mono, uppercase, wide tracking (source: nd-botanical-btn-* + Header/Home usage)
export function Button({ variant = 'primary', size = 'md', href, onClick, disabled, children, style }) {
  const [hover, setHover] = React.useState(false);
  const pads = { sm: '10px 16px', md: '14px 24px', lg: '22px 32px' };
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 12,
    fontFamily: 'var(--font-mono)', fontSize: size === 'sm' ? 12 : 14, fontWeight: 600,
    textTransform: 'uppercase', letterSpacing: '0.05em', borderRadius: 'var(--radius)',
    padding: pads[size], border: '1px solid transparent', cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all 0.3s ease', textDecoration: 'none', opacity: disabled ? 0.5 : 1,
    transform: hover && !disabled ? 'translateY(-1px)' : 'none',
  };
  const variants = {
    primary: { backgroundColor: hover && !disabled ? 'var(--color-primary-hover)' : 'var(--color-primary)', color: '#fff', boxShadow: hover && !disabled ? 'var(--shadow-btn-primary)' : 'none' },
    accent: { backgroundColor: hover && !disabled ? 'var(--color-accent-hover)' : 'var(--color-accent)', color: '#fff', boxShadow: hover && !disabled ? 'var(--shadow-btn-accent)' : 'none' },
    secondary: { backgroundColor: hover && !disabled ? 'rgba(4,120,87,0.05)' : 'var(--color-surface)', color: hover && !disabled ? 'var(--color-primary)' : 'var(--color-text)', border: `1px solid ${hover && !disabled ? 'var(--color-primary)' : 'var(--color-border)'}`, transform: 'none', boxShadow: 'none' },
  };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} onClick={disabled ? undefined : onClick} disabled={!href && disabled ? true : undefined}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ ...base, ...variants[variant], ...style }}>
      {children}
    </Tag>
  );
}
