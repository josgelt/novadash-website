Card surface used for features, pricing tiers, floating hero widgets.

```jsx
<Card><FeatureIcon name="truck" accent /><h3>…</h3><p>…</p></Card>
<Card dark>…</Card>  // white/5 panel on deep-forest sections
```

Hover: border → emerald, lifts 2px over 0.4s. Set hoverable={false} for static surfaces.
