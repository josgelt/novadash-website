import React from 'react';
// Short rounded accent bar under section titles (source: w-12 h-1 rounded)
export function Divider({ onDark = false, style }) {
  return <div style={{ width: 48, height: 4, borderRadius: 4, background: onDark ? 'var(--color-primary)' : 'var(--color-text)', ...style }}></div>;
}
