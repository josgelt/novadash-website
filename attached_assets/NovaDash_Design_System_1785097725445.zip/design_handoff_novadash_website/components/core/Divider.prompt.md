Short 48×4 rounded bar under section titles — ink on light, emerald on dark sections.

```jsx
<Divider style={{margin:'0 0 32px'}} />
<Divider onDark />
```
