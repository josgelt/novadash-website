Lucide stroke icon by name — the glyph set the NovaDash source imports from lucide-react.

```jsx
<Icon name="check-circle-2" size={14} />
<Icon name="truck" size={22} strokeWidth={1.5} />
```

Names: package, shield-check, activity, arrow-right, globe, truck, check-circle-2, terminal, menu, x. Inherits `currentColor`.
