/** Mono uppercase badge chip — hero announcements, "Beliebt" tags, trust badges. */
export interface BadgeProps {
  /** 'outline' (white, emerald-tinted border) | 'solid' (emerald) | 'tint' (10% emerald) | 'dark' (for dark sections). Default 'outline'. */
  variant?: 'outline' | 'solid' | 'tint' | 'dark';
  /** Optional leading icon node (e.g. <Icon name="terminal" size={14}/>). */
  icon?: React.ReactNode;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
