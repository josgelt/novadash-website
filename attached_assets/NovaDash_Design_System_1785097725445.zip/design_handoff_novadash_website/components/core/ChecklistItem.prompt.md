Checklist row with the 10%-emerald check disc.

```jsx
<ChecklistItem boxed>Kein Einloggen in 5 verschiedene Portale mehr</ChecklistItem>
<ChecklistItem>Bis zu 2.000 Bestellungen/Monat</ChecklistItem>
```

boxed = white bordered row (Home benefits); plain = pricing-tier feature lists.
