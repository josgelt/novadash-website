/** Checklist row: emerald check disc + text; optionally boxed in a white bordered row. */
export interface ChecklistItemProps {
  /** Wrap in a white bordered row (Home problem-section style). Default false = plain (pricing-tier style). */
  boxed?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
