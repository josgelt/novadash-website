48px bordered icon tile for feature-card headers.

```jsx
<FeatureIcon name="globe" />
<FeatureIcon name="truck" accent />
```
