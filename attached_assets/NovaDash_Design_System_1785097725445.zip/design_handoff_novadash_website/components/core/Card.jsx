import React from 'react';
// nd-botanical-card: white, hairline, 12px radius; hover = emerald border + lift (source CSS)
export function Card({ dark = false, padding = 32, hoverable = true, children, style }) {
  const [hover, setHover] = React.useState(false);
  const light = {
    background: 'var(--color-surface)', border: `1px solid ${hover && hoverable ? 'var(--color-primary)' : 'var(--color-border)'}`,
    borderRadius: 'var(--radius-card)', transition: 'all 0.4s ease', position: 'relative', padding,
    transform: hover && hoverable ? 'translateY(-2px)' : 'none', boxShadow: hover && hoverable ? 'var(--shadow-card)' : 'none',
  };
  const darkS = {
    background: 'rgba(255,255,255,0.05)', border: `1px solid ${hover && hoverable ? 'rgba(4,120,87,0.5)' : 'rgba(255,255,255,0.1)'}`,
    borderRadius: 'var(--radius)', transition: 'border-color 0.3s ease', padding: 24, color: '#fff',
  };
  return <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ ...(dark ? darkS : light), ...style }}>{children}</div>;
}
