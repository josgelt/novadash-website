Mono uppercase eyebrow label that sits above every section heading.

```jsx
<Eyebrow>Core Features</Eyebrow>
<Eyebrow color="accent" style={{marginBottom:16}}>Skalierbarkeit</Eyebrow>
```
