/** 48px bordered icon tile used at the top of feature cards. */
export interface FeatureIconProps {
  /** Icon name (see Icon component). */
  name: string;
  /** Teal instead of emerald stroke. Default false. */
  accent?: boolean;
  style?: React.CSSProperties;
}
