/**
 * NovaDash button — mono uppercase wide-tracked; solid emerald primary, teal accent, outlined secondary.
 */
export interface ButtonProps {
  /** 'primary' (solid emerald) | 'accent' (solid teal) | 'secondary' (white, hairline border). Default 'primary'. */
  variant?: 'primary' | 'accent' | 'secondary';
  /** 'sm' | 'md' | 'lg'. Default 'md'; hero CTAs use 'lg'. */
  size?: 'sm' | 'md' | 'lg';
  /** Renders an <a> instead of <button>. */
  href?: string;
  onClick?: () => void;
  disabled?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
