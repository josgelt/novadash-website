/** 48×4px rounded accent bar placed under section titles. */
export interface DividerProps {
  /** Emerald bar on dark sections; ink bar on light. Default false. */
  onDark?: boolean;
  style?: React.CSSProperties;
}
