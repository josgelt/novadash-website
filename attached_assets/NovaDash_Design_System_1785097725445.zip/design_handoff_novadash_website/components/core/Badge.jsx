import React from 'react';
// Mono uppercase badge chips (source: hero badge, BELIEBT tag, trust badge, pricing notice)
export function Badge({ variant = 'outline', icon, children, style }) {
  const base = { display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', borderRadius: 'var(--radius-sm)', padding: '6px 12px' };
  const variants = {
    outline: { border: '1px solid rgba(4,120,87,0.3)', background: '#fff', color: 'var(--color-primary)', boxShadow: '0 1px 2px rgba(0,0,0,0.05)' },
    solid: { background: 'var(--color-primary)', color: '#fff', padding: '4px 16px' },
    tint: { background: 'rgba(4,120,87,0.1)', color: 'var(--color-primary)', fontWeight: 700 },
    dark: { border: '1px solid rgba(255,255,255,0.2)', background: 'rgba(255,255,255,0.05)', color: '#fff', padding: '8px 16px' },
  };
  return <span style={{ ...base, ...variants[variant], ...style }}>{icon}{children}</span>;
}
