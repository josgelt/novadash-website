/** NovaDash card surface — white, hairline border, 12px radius, hover lift + emerald border. */
export interface CardProps {
  /** Translucent white/5 panel for dark (deep forest) sections. Default false. */
  dark?: boolean;
  /** Inner padding px. Default 32. */
  padding?: number;
  /** Disable the hover lift/border effect. Default true. */
  hoverable?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
