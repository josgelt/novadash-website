import React from 'react';
import { Icon } from './Icon.jsx';
// 48px icon tile: off-white bg, hairline border, emerald/teal stroke icon (source: feature cards)
export function FeatureIcon({ name, accent = false, style }) {
  return <div style={{ width: 48, height: 48, background: 'var(--color-bg)', borderRadius: 'var(--radius)', border: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: accent ? 'var(--color-accent)' : 'var(--color-primary)', ...style }}><Icon name={name} size={22} strokeWidth={1.5} /></div>;
}
