Mono uppercase badge chip for announcements and tags.

```jsx
<Badge variant="outline" icon={<Icon name="terminal" size={14} style={{color:'var(--color-accent)'}}/>}>V2.0 Beta live</Badge>
<Badge variant="solid">Beliebt</Badge>
```

Variants: outline (hero/pricing notices), solid (popular-plan tag), tint (price-teaser label), dark (dark trust sections).
