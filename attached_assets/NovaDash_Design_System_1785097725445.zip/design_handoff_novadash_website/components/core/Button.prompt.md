NovaDash CTA button: JetBrains Mono, uppercase, wide tracking; use for every action.

```jsx
<Button variant="primary" size="lg">Early Access anfragen <Icon name="arrow-right" size={16} /></Button>
<Button variant="secondary">Funktionen ansehen</Button>
```

Variants: primary (solid emerald, hover darkens+lifts+glow), accent (solid teal), secondary (white + hairline border, hover emerald border/text). Sizes sm/md/lg — hero CTAs are lg.
