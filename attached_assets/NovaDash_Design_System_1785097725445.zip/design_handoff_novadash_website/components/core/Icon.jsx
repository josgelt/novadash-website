import React from 'react';
// Lucide icon set — exact glyphs imported by the source (lucide-react). 24x24, stroke-based.
const P = {
  'package': ['M7.5 4.27 9 5.15','M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z','M3.3 7 12 12l8.7-5','M12 22V12'],
  'shield-check': ['M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z','m9 12 2 2 4-4'],
  'activity': ['M22 12h-4l-3 9L9 3l-3 9H2'],
  'arrow-right': ['M5 12h14','m12 5 7 7-7 7'],
  'globe': ['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Z','M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20','M2 12h20'],
  'truck': ['M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2','M15 18H9','M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14','M17 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm0 0h.01','M7 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z'],
  'check-circle-2': ['M21.801 10A10 10 0 1 1 17 3.335','m9 11 3 3L22 4'],
  'terminal': ['m4 17 6-6-6-6','M12 19h8'],
  'menu': ['M4 12h16','M4 6h16','M4 18h16'],
  'x': ['M18 6 6 18','m6 6 12 12'],
};
export function Icon({ name, size = 16, strokeWidth = 2, style }) {
  const paths = P[name] || [];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style} aria-hidden="true">
      {paths.map((d, i) => <path key={i} d={d} />)}
    </svg>
  );
}
