/** Lucide stroke icon by name. Set of glyphs used across NovaDash. */
export interface IconProps {
  /** One of: package, shield-check, activity, arrow-right, globe, truck, check-circle-2, terminal, menu, x */
  name: string;
  /** px, default 16 (source uses 14–24) */
  size?: number;
  /** default 2; feature-tile icons use 1.5 */
  strokeWidth?: number;
  style?: React.CSSProperties;
}
