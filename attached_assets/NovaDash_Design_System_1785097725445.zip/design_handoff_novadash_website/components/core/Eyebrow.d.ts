/** Mono uppercase section eyebrow label above headings. */
export interface EyebrowProps {
  /** 'primary' | 'accent' | 'muted' | 'onDark'. Default 'primary'. */
  color?: 'primary' | 'accent' | 'muted' | 'onDark';
  children: React.ReactNode;
  style?: React.CSSProperties;
}
