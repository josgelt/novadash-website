import React from 'react';
import { Icon } from './Icon.jsx';
// Checklist row: check-circle in 10%-emerald disc + text (source: Home bullets, Pricing features)
export function ChecklistItem({ boxed = false, children, style }) {
  const [hover, setHover] = React.useState(false);
  const disc = <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'rgba(4,120,87,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: boxed ? 0 : 2, color: 'var(--color-primary)' }}><Icon name="check-circle-2" size={14} /></div>;
  if (boxed) return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 16, borderRadius: 'var(--radius)', background: '#fff', border: `1px solid ${hover ? 'rgba(4,120,87,0.5)' : 'var(--color-border)'}`, boxShadow: '0 1px 2px rgba(0,0,0,0.05)', transition: 'border-color 0.3s ease', ...style }}>{disc}<span style={{ fontWeight: 500, color: 'var(--color-text)' }}>{children}</span></div>
  );
  return <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, ...style }}>{disc}<span style={{ fontSize: 14, lineHeight: 1.6, color: 'var(--color-text)' }}>{children}</span></div>;
}
