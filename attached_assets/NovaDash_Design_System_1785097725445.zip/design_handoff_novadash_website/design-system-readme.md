# NovaDash Design System — "Editorial Botanical"

NovaDash is a cloud-based order-management SaaS for e-commerce merchants in the DACH region (Germany, Austria, Switzerland). It centralizes orders, shipping and tracking from marketplaces (Amazon, eBay, Shopify) and carriers (DHL, GLS, Sendcloud). The brand is bilingual German/English; the marketing site is German-first.

**Products represented:** the marketing website (source of this system). A SaaS dashboard app is planned but no dashboard source was provided — the system is designed to scale to it, but no dashboard UI kit was invented.

## Sources
- Attached codebase: `novadash-claude-design-package/claude-design-package/` (read-only local mount) — production `Header.tsx`, `Footer.tsx`, `Layout.tsx`, pages `Home.tsx`, `Pricing.tsx`, `Uptime.tsx`, live Tailwind v4 theme (`styles/index.css`), portable CSS (`styles/novadash-design-system.css`), fonts setup, and screenshots (copied to `reference/`).
- All fonts are Google Fonts (Cormorant Garamond, Nunito, JetBrains Mono) — no font binaries needed.

## CONTENT FUNDAMENTALS
- **Tone:** professional, precise, confident — B2B but human. Calm authority, no hype, no exclamation marks, no emoji.
- **Bilingual DE/EN**, German-first. German copy uses formal "Sie" ("Verwalten Sie Bestellungen…"), never "du". Nav routes are German (`/funktionen`, `/preise`, `/ueber-uns`).
- **Headline pattern:** short declarative pairs with a serif-italic accent word in emerald — "Alle Marktplätze. *Eine* Oberfläche." / "Alles an einem Ort. *Vollautomatisiert.*"
- **Eyebrows/labels:** UPPERCASE JetBrains Mono with wide tracking — "SKALIERBARKEIT", "CORE FEATURES", "V2.0 BETA LIVE".
- **Body copy:** benefit-led, concrete, quantified ("Was mit 10 Bestellungen am Tag funktionierte, führt bei 100 zum Systemkollaps."). Technical values rendered in mono (`#10492-DE`, `SYNCED`, `REST_API`).
- **CTAs:** uppercase mono, imperative — "EARLY ACCESS ANFRAGEN", "FUNKTIONEN ANSEHEN".
- **Casing:** sentence case for body/headlines; uppercase reserved for mono labels/buttons/nav.

## VISUAL FOUNDATIONS
- **Colors:** deep emerald `#047857` primary (CTAs, accents, italic accent words); deep forest `#064E3B` for dark trust sections; deep teal `#0F766E` secondary accent; warm off-white `#F8FAF9` page bg, `#F1F5F2` alt; ink `#111814`; muted `#4B5A52`; hairline `#E2E8E4`. Max two background tones per page plus one dark section.
- **Type:** Cormorant Garamond (serif, wt 500–600) for all headings and the logo — italic 500 for accent words; Nunito for body; JetBrains Mono for eyebrows/nav/buttons/prices. Hero ≈72px serif, leading 1.1; section titles 36–48px.
- **Backgrounds:** flat off-white with faint dot texture (`radial-gradient`, 20px grid) or hairline grid (40px), at 30–50% opacity; huge soft radial brand-color glows (600px, blur 100px, opacity 0.05–0.07) in corners. No photography backdrops, no gradients as fills.
- **Imagery:** product screenshots in white browser-chrome frames (traffic lights), soft warm-neutral photography with subtle green accents; framed with hairline border + generous shadow.
- **Cards:** white surface, 1px `#E2E8E4` hairline, 12px radius, near-invisible shadow; hover = border turns emerald + lift `translateY(-2px)` over 0.4s ease.
- **Buttons:** mono uppercase wide-tracked; primary solid emerald (hover darkens, lifts 1px, gains soft emerald glow shadow); secondary white with hairline border (hover: emerald border + text + 5% emerald tint). Generous padding (px-8 py-6).
- **Motion:** restrained entrance-only fade/slide-up (20px, 1s, `cubic-bezier(0.2,0.8,0.2,1)`), staggered 100–300ms. Hovers are 0.3s color/lift transitions. No bounces, no loops.
- **Borders/dividers:** hairlines everywhere; short 48×4px rounded ink (or emerald on dark) bar under section titles.
- **Radii:** 8px buttons/badges, 12px cards, 16px framed imagery. Layout: fixed header that gains blur+hairline on scroll; max-w-7xl containers; sections py-28/32.
- **Transparency/blur:** only the scrolled header (`bg/90` + backdrop-blur) and white/5–white/10 panels on dark sections.
- **Dark sections:** deep forest bg, white text at 70–80% opacity for body, emerald mono accents, white/10 bordered cards.

## ICONOGRAPHY
- **Icon system: [Lucide](https://lucide.dev)** (`lucide-react` in source) — stroke icons, `strokeWidth` 1.5–2, sizes 14–24. Used: Package, ShieldCheck, Activity, ArrowRight, Globe, Truck, CheckCircle2, Terminal, Menu. In this system icons load from the Lucide CDN (`lucide` UMD) — same set, not a substitution.
- Feature icons sit in 48px tiles: off-white bg, hairline border, 8px radius, emerald or teal stroke.
- Checkmarks: `CheckCircle2` at 14px inside a 20px circle of 10% emerald.
- No icon font, no emoji, no unicode-as-icon. Numbered items use mono "01/02/03".
- **Logo:** "Nova [barcode] Dash" — Space Grotesk Medium wordmark (`--font-display`), an emerald barcode glyph replacing the dash. Use the `Logo` component (`variant="dark"` on dark surfaces), `LogoIcon` for the square app-icon mark; assets: `assets/logo.svg`, `assets/logo-icon.svg`. Never recreate the old serif-N square; never letter-space the wordmark.
- Integration partners (Amazon, eBay, …) are rendered as styled *text*, not logos.

## Index
- `styles.css` → `tokens/` (fonts, colors, typography, spacing, helpers)
- `components/core/` — Button, Badge, Eyebrow, Divider, Card, ChecklistItem, FeatureIcon
- `components/brand/` — Logo
- `ui_kits/marketing-site/` — Home / Pricing / Uptime click-through recreation
- `guidelines/` — specimen cards for the Design System tab
- `reference/` — source screenshots
- `SKILL.md` — agent skill entry point

## Intentional additions
- `FeatureIcon` (icon-tile wrapper) — the 48px bordered icon tile recurs on every feature card in source; extracted for reuse.
- `Icon` — wrapper exposing the exact Lucide glyphs the source imports from `lucide-react` (package, shield-check, activity, arrow-right, globe, truck, check-circle-2, terminal, menu, x).

## Not invented (absent from source)
- Dashboard app UI, Input/Select/form controls, Tabs, Toast, Tooltip, Avatar — none exist in the provided marketing-site source, so none were authored.
